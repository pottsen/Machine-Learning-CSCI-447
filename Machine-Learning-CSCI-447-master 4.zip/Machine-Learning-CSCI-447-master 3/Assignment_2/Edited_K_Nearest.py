

def edited_k_nearest(k, test_data, training_data):
    
    for index,row


# return 