# Machine-Learning-CSCI-447
Authors:
Bruce Clark
Peter Ottsen
Justin McGowen
Forest Edwards

In no particular order